import 'react-native-gesture-handler';
import {NavigationContainer} from '@react-navigation/native';
import React, { Component } from 'react';
import Home from './pages/Home';
import Login from './pages/Login';
import ApiPage from './pages/ApiPage';


export default class App extends React.Component {
  render() {
    return (
      <ApiPage></ApiPage>
    );
  }
}